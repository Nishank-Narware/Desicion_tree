# decision_tree

*company*:codtech it solutions

*name* :vartika Kushwaha

*intern id* :CT04DH759

*domain*:Machine learning

*duration*:4 weeks

Decision Tree Classifier is a method used to classify data into categories like "Yes" or "No" or different types such as "Spam" or "Not Spam". It works by using a tree-like structure that asks questions to split the data step-by-step. These splits are based on input features to help the model make accurate predictions. At the end of each branch called a leaf node the model assigns a class label based on the majority of the data in that group.

*output*
<img width="1415" height="1175" alt="image" src="https://github.com/user-attachments/assets/199dd9ba-63ae-42c0-b9b1-4b55af8f22cc" />
